package com.example.estacionamento.Estacionamento;

public class TabelaPreco {
}
